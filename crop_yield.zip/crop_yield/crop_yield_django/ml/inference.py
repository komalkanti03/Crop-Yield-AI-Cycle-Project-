import joblib
from pathlib import Path
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent.parent
MODEL_PATH = BASE_DIR / 'ml' / 'model.pkl'

_EXPECTED = [
    'crop_type', 'region', 'soil_n', 'soil_p', 'soil_k',
    'rainfall_mm', 'avg_temp_c', 'fertilizer_kg_per_ha',
    'pesticide_l_per_ha', 'sowing_month'
]

_model_cache = None

def load_model():
    global _model_cache
    if _model_cache is None:
        _model_cache = joblib.load(MODEL_PATH)
    return _model_cache

def predict(payload: dict) -> float:
    model = load_model()
    row = {k: payload.get(k, None) for k in _EXPECTED}
    df = pd.DataFrame([row])
    y = float(model.predict(df)[0])
    return round(y, 2)
