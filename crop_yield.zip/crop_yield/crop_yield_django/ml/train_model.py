import pandas as pd
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.metrics import r2_score, mean_absolute_error
from sklearn.ensemble import RandomForestRegressor
import joblib

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_PATH = BASE_DIR / 'data' / 'crop_yield_2000.csv'
MODEL_PATH = BASE_DIR / 'ml' / 'model.pkl'

print('Loading:', DATA_PATH)
df = pd.read_csv(DATA_PATH)

X = df.drop(columns=['yield_kg_per_ha'])
y = df['yield_kg_per_ha']

cat_features = ['crop_type', 'region']
num_features = ['soil_n','soil_p','soil_k','rainfall_mm','avg_temp_c','fertilizer_kg_per_ha','pesticide_l_per_ha','sowing_month']

numeric_pipeline = Pipeline([
    ('imputer', SimpleImputer(strategy='median')),
    ('scaler', StandardScaler())
])

categorical_pipeline = Pipeline([
    ('imputer', SimpleImputer(strategy='most_frequent')),
    ('ohe', OneHotEncoder(handle_unknown='ignore'))
])

preprocess = ColumnTransformer([
    ('num', numeric_pipeline, num_features),
    ('cat', categorical_pipeline, cat_features)
])

model = RandomForestRegressor(
    n_estimators=350,
    min_samples_split=4,
    random_state=42,
    n_jobs=-1
)

pipe = Pipeline([
    ('prep', preprocess),
    ('model', model)
])

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

pipe.fit(X_train, y_train)

pred = pipe.predict(X_test)
r2 = r2_score(y_test, pred)
mae = mean_absolute_error(y_test, pred)
print(f"TEST -> R2: {r2:.3f} | MAE: {mae:.1f} kg/ha")

MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
joblib.dump(pipe, MODEL_PATH)
print('Saved ->', MODEL_PATH)
