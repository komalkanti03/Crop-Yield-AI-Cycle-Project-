from django.db import models

class PredictionLog(models.Model):
    ts = models.DateTimeField(auto_now_add=True)
    crop_type = models.CharField(max_length=20)
    region = models.CharField(max_length=30)
    soil_n = models.FloatField(null=True)
    soil_p = models.FloatField(null=True)
    soil_k = models.FloatField(null=True)
    rainfall_mm = models.FloatField(null=True)
    avg_temp_c = models.FloatField(null=True)
    fertilizer_kg_per_ha = models.FloatField(null=True)
    pesticide_l_per_ha = models.FloatField(null=True)
    sowing_month = models.IntegerField(null=True)
    prediction = models.FloatField()

    def __str__(self):
        return f"{self.ts} — {self.crop_type}/{self.region} → {self.prediction:.1f} kg/ha"
