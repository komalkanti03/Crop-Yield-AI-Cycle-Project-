from django.contrib import admin
from .models import PredictionLog

@admin.register(PredictionLog)
class PredictionLogAdmin(admin.ModelAdmin):
    list_display = ('ts', 'crop_type', 'region', 'prediction')
    list_filter = ('crop_type', 'region')
    search_fields = ('crop_type', 'region')
