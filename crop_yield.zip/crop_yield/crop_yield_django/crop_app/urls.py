from django.urls import path
from .views import index, api_predict

urlpatterns = [
    path('', index, name='index'),
    path('api/predict', api_predict, name='api_predict'),
]
