from django import forms

CROP_CHOICES = [(c, c) for c in ["Wheat", "Rice", "Maize", "Soybean", "Cotton"]]
REGION_CHOICES = [(r, r) for r in ["Maharashtra", "Punjab", "Gujarat", "Bihar", "Karnataka", "UP"]]

class PredictForm(forms.Form):
    crop_type = forms.ChoiceField(choices=CROP_CHOICES)
    region = forms.ChoiceField(choices=REGION_CHOICES)
    soil_n = forms.FloatField(initial=45)
    soil_p = forms.FloatField(initial=28)
    soil_k = forms.FloatField(initial=35)
    rainfall_mm = forms.FloatField(initial=120)
    avg_temp_c = forms.FloatField(initial=24)
    fertilizer_kg_per_ha = forms.FloatField(required=False)
    pesticide_l_per_ha = forms.FloatField(initial=1.2)
    sowing_month = forms.IntegerField(min_value=1, max_value=12, initial=11)
