from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from .forms import PredictForm
from .models import PredictionLog
from ml.inference import predict as ml_predict
import json

def index(request):
    pred_value = None
    form = PredictForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        payload = form.cleaned_data
        pred_value = ml_predict(payload)
        PredictionLog.objects.create(prediction=pred_value, **payload)
    return render(request, 'predict.html', { 'form': form, 'pred': pred_value })

@csrf_exempt
def api_predict(request):
    if request.method != 'POST':
        return JsonResponse({'error': 'POST required'}, status=405)
    try:
        data = json.loads(request.body.decode('utf-8'))
        pred_value = ml_predict(data)
        payload = { **{k: None for k in ['crop_type','region','soil_n','soil_p','soil_k','rainfall_mm','avg_temp_c','fertilizer_kg_per_ha','pesticide_l_per_ha','sowing_month']}, **data }
        PredictionLog.objects.create(prediction=pred_value, **payload)
        return JsonResponse({'pred_yield_kg_per_ha': pred_value})
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=400)
